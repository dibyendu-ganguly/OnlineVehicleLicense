export class Challan {

    challanNumber : string = "";
    vehicleNumber : string = "";
    amount : number = 0.00;
    status : string = "";
    
    constructor(){};
    
}