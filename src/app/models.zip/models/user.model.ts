export class Users {

    username: string = "";
    email: string = "";
    password: string = "";

    constructor(){};
    
}