export class Documents {

    id : string = "";
    photo : string = "";
    idProof : string = "";
    addressProof : string = "";
    
    constructor(){};
    
}