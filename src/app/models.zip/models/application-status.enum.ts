export enum ApplicationStatus {

    PENDING = "PENDING",
    APPROVED = "APPROVED",
    REJECTED = "REJECTED"

}