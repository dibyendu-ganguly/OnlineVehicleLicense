export enum AddressType {

    PERMANENT = "PERMANENT",
    PRESENT = "PRESENT"
    
}