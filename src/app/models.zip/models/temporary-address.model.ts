export class TemporaryAddress {

    addrId : string = "";
    house : string = "";
    city : string = "";
    state : string = "";
    landmark : string = "";
    pincode : number = 0;

    constructor(){};
}