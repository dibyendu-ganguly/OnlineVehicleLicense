export class RtoOffice {

    rtoId : number = 0;
    rtoName : string = "";
    
    constructor(){};
    
}