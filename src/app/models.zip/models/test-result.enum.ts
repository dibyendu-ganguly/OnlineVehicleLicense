export enum TestResult {

    PENDING = "PENDING",
    PASS = "PASS",
    FAIL = "FAIL"
    
}