export class Address {

    addrId : string = "";
    house : string = "";
    city : string = "";
    state : string = "";
    landmark : string = "";
    pincode : number = 0;
    
    constructor(){};
}