export enum LicenseType {

    DL = "DL",
    LL = "LL"
    
}