export class RtoOfficer {

    username : string = "";
    email : string = "";
    password : string = "";
    
    constructor(){};
}